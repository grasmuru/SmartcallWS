﻿/* Written by Tiaan Lombard - tiaanlombard@live.co.za*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Smartcall_C_Sharp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


           
            smartcallservicereference.SmartloadServiceClient ws = new smartcallservicereference.SmartloadServiceClient();
            smartcallservicereference.DealerBalanceResponse resp = ws.getDealerBalance();
            MessageBox.Show(resp.responseCode + " : " + resp.balance.ToString ());

        }
    }
}
