﻿'Written by Tiaan Lombard - tiaanlombard@live.co.za
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim ws As smartcallservicereference.SmartloadServiceClient = New smartcallservicereference.SmartloadServiceClient
            Dim resp As smartcallservicereference.DealerBalanceResponse = ws.getDealerBalance
            MessageBox.Show(resp.responseCode.ToString & " : " & resp.balance.ToString)
        Catch ex As Exception
            MessageBox.Show(ex.InnerException.Message)
        End Try
    End Sub
End Class
